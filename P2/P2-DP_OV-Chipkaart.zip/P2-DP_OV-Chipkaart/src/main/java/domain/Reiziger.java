package domain;
import java.sql.Date;

public class Reiziger
{
    private int id;
    private String voorletters;
    private String tussenvoegsel;
    private String achternaam;
    private Date geboortedatum;

    public Reiziger()
    {
    }

    public Reiziger(int id, String voorletters, String tussenvoegsel, String achternaam, Date geboortedatum)
    {
        this.id = id;
        this.voorletters = voorletters;
        this.tussenvoegsel = tussenvoegsel;
        this.achternaam = achternaam;
        this.geboortedatum = geboortedatum;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getVoorletters()
    {
        return voorletters;
    }

    public void setVoorletters(String voorletters)
    {
        this.voorletters = voorletters;
    }

    public String getTussenvoegsel()
    {
        return tussenvoegsel;
    }

    public void setTussenvoegsel(String tussenvoegsel)
    {
        this.tussenvoegsel = tussenvoegsel;
    }

    public String getAchternaam()
    {
        return achternaam;
    }

    public void setAchternaam(String achternaam)
    {
        this.achternaam = achternaam;
    }

    public Date getGeboortedatum()
    {
        return geboortedatum;
    }

    public void setGeboortedatum(Date geboortedatum)
    {
        this.geboortedatum = geboortedatum;
    }

    public String getNaam()
    {
        if (tussenvoegsel == null || tussenvoegsel.isBlank())
        {
            return voorletters + " " + achternaam;
        }
        return voorletters + " " + tussenvoegsel + " " + achternaam;
    }

    @Override
    public String toString()
    {
        String tv = "";
        if (tussenvoegsel != null && !tussenvoegsel.isBlank())
        {
            tv = " " + tussenvoegsel;
        }
        return String.format("Reiziger #%d %s%s %s (%s)", id, voorletters, tv, achternaam, geboortedatum);
    }
}