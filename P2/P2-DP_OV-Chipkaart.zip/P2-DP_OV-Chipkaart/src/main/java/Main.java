import DAO.ReizigerDAO;
import DAO.ReizigerDAOPsql;
import domain.Reiziger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class Main
{
    private static final String _url = "jdbc:postgresql://localhost:5432/ovchip";
    private static final String _gebruikersnaam = "postgres";
    private static final String _wachtwoord = "postgres";

    private static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(_url, _gebruikersnaam, _wachtwoord);
    }

    public static void main(String[] args)
    {
        try (Connection conn = getConnection())
        {
            ReizigerDAO reizigerDAO = new ReizigerDAOPsql(conn);
            testReizigerDAO(reizigerDAO);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * P2. Reiziger DAO: persistentie van een klasse
     *
     * Deze methode test de CRUD-functionaliteit van de Reiziger DAO
     *
     * @throws SQLException
     */
    private static void testReizigerDAO(ReizigerDAO rdao) throws SQLException
    {
        System.out.println("\n---------- Test ReizigerDAO -------------");

        // Haal alle reizigers op uit de database
        List<Reiziger> reizigers = rdao.findAll();
        System.out.println("[Test] ReizigerDAO.findAll() geeft de volgende reizigers:");
        for (Reiziger r : reizigers) {
            System.out.println(r);
        }
        System.out.println();

        // Zorg dat een eventuele oude reiziger met id 77 eerst is verwijderd, zodat de test herhaalbaar is.
        Reiziger bestaand = rdao.findById(77);
        if (bestaand != null)
        {
            rdao.delete(bestaand);
        }

        // Maak een nieuwe reiziger aan en persisteer deze in de database
        String gbdatum = "1981-03-14";
        Reiziger sietske = new Reiziger(77, "S", "", "Boers", java.sql.Date.valueOf(gbdatum));
        System.out.print("[Test] Eerst " + reizigers.size() + " reizigers, na ReizigerDAO.save() ");
        rdao.save(sietske);
        reizigers = rdao.findAll();
        System.out.println(reizigers.size() + " reizigers\n");

        // Test findById
        System.out.println("[Test] ReizigerDAO.findById(77) geeft: ");
        Reiziger gevonden = rdao.findById(77);
        System.out.println(gevonden);
        System.out.println();

        // Test findByGbdatum
        System.out.println("[Test] ReizigerDAO.findByGbdatum(\"" + gbdatum + "\") geeft de volgende reizigers: ");
        List<Reiziger> reizigersOpGbdatum = rdao.findByGbdatum(Date.valueOf(gbdatum));
        for (Reiziger r : reizigersOpGbdatum)
        {
            System.out.println(r);
        }
        System.out.println();

        // Test update
        System.out.println("[Test] ReizigerDAO.update() wijzigt achternaam van Sietske naar 'Boersma'");
        sietske.setAchternaam("Boersma");
        rdao.update(sietske);
        System.out.println("Na update: " + rdao.findById(77));
        System.out.println();

        // Test delete
        System.out.print("[Test] Aantal reizigers voor delete: " + rdao.findAll().size() + ", na ReizigerDAO.delete(): ");
        rdao.delete(sietske);
        System.out.println(rdao.findAll().size());
    }
}