import java.sql.*;

import static java.sql.DriverManager.getConnection;

public class Main
{
    private static final String _url = "jdbc:postgresql://localhost:5432/ovchip";
    private static final String _gebruikersnaam = "postgres";
    private static final String _wachtwoord = "postgres";

    private static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(_url, _gebruikersnaam, _wachtwoord);
    }

    public static void main(String[] args)
    {
        try (Connection conn = getConnection())
        {
            printAlleReizigers(conn);
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    private static void printAlleReizigers(Connection conn) throws SQLException {

        String sql = """
                SELECT reiziger_id,
                       voorletters,
                       tussenvoegsel,
                       achternaam,
                       geboortedatum
                FROM reiziger
                ORDER BY reiziger_id
                """;

        System.out.println("Alle reizigers:");

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery())
        {
            while (rs.next())
            {
                int id = rs.getInt("reiziger_id");
                String voorletters = rs.getString("voorletters");
                String tussenvoegsel = rs.getString("tussenvoegsel");
                String achternaam = rs.getString("achternaam");
                Date geboortedatum = rs.getDate("geboortedatum");

                String achternaamVolledig;

                if(tussenvoegsel == null || tussenvoegsel.isBlank())
                {
                    achternaamVolledig = achternaam;
                }
                else
                {
                    achternaamVolledig = tussenvoegsel + " " + achternaam;
                }

                System.out.printf("    #%d: %s %s (%s)%n", id, voorletters, achternaamVolledig, geboortedatum);
            }
        }
    }
}